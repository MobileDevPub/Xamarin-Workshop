HTTP Client
===========

An example on using both the .NET and Objective-C classes to
send a web request in one MonoTouch application.


Authors
-------

Miguel de Icaza
